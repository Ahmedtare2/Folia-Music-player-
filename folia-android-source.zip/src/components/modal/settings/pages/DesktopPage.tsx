import React from 'react';
import { useTranslation } from 'react-i18next';
import { useShallow } from 'zustand/react/shallow';
import { useDesktopSettingsStore } from '../../../../stores/useDesktopSettingsStore';
import { usePlayerChromeSettingsStore } from '../../../../stores/usePlayerChromeSettingsStore';
import { UI_ZOOM_STEPS, readUiZoomStep } from '../../../../utils/uiZoom';
import { Group, Reveal, Row, Select, Toggle, Segmented, option, type SettingsGroupDef, type SettingsOptionDef } from '../kit';
import { WallpaperDisplayRow } from './desktop/WallpaperDisplayRow';
import { hasWallpaperDisplayChoice } from './desktop/wallpaperDisplays';

// src/components/modal/settings/pages/DesktopPage.tsx
// The 桌面 page (desktop app only): the main window's page zoom (界面缩放, #1264), what it does with
// the tray, the taskbar and its fullscreen button, and the wallpaper mode. The Remote Control window has a page of its own (RemotePage).

const WINDOW: SettingsGroupDef = { id: 'desktopTrayBehavior', titleKey: 'options.desktopTrayBehavior', electronOnly: true };

const O = {
    uiZoom: option(WINDOW, 'uiZoom', 'options.uiZoom'),
    uiZoomStep: option(WINDOW, 'uiZoomStep', 'options.uiZoomStep'),
    minimizeToTray: option(WINDOW, 'minimizeToTray', 'options.minimizeToTray'),
    closeToTray: option(WINDOW, 'closeToTray', 'options.closeToTray'),
    hideTaskbarIcon: option(WINDOW, 'hideTaskbarIcon', 'options.hideTaskbarIcon'),
    titlebarSide: option(WINDOW, 'titlebarSide', 'options.titlebarSide'),
    hideFullscreenButton: option(WINDOW, 'hideFullscreenButton', 'options.hideFullscreenButton'),
    nativeMacFullscreen: option(WINDOW, 'useNativeMacFullscreenButton', 'options.useNativeMacFullscreenButton'),
    nativeMacTrafficLights: option(WINDOW, 'useNativeMacTrafficLights', 'options.useNativeMacTrafficLights'),
    wallpaperMode: option(WINDOW, 'wallpaperMode', 'options.wallpaperMode'),
    // Drawn only with more than one display connected, where wallpaper mode can use any of them.
    wallpaperDisplay: option(WINDOW, 'wallpaperDisplay', 'options.wallpaperDisplay', { available: hasWallpaperDisplayChoice }),
    wallpaperDock: option(WINDOW, 'wallpaperMacAutohideDock', 'options.wallpaperMacAutohideDock'),
};

const PLATFORM = typeof window === 'undefined' ? undefined : window.electron?.platform;
const IS_MAC = PLATFORM === 'darwin';
const HAS_WALLPAPER_MODE = IS_MAC || PLATFORM === 'win32' || PLATFORM === 'linux';
const UI_ZOOM_CHOICES = UI_ZOOM_STEPS.map(step => ({ value: String(step), label: `${step}%` }));
const MAC_ONLY: SettingsOptionDef[] = [O.nativeMacFullscreen, O.nativeMacTrafficLights, O.wallpaperDock];

// The search lists the two macOS rows only on macOS.
export const OPTIONS: SettingsOptionDef[] = Object.values(O).filter(row => IS_MAC || !MAC_ONLY.includes(row));

const DesktopPage: React.FC = () => {
    const { t } = useTranslation();
    const desktop = useDesktopSettingsStore(useShallow(state => ({
        minimizeToTray: state.minimizeToTray,
        closeToTray: state.closeToTray,
        hideTaskbarIcon: state.hideTaskbarIcon,
        uiZoomEnabled: state.uiZoomEnabled,
        uiZoomStep: state.uiZoomStep,
        wallpaperMode: state.wallpaperMode,
        wallpaperDock: state.wallpaperMacAutohideDock,
        setMinimizeToTray: state.handleToggleMinimizeToTray,
        setCloseToTray: state.handleToggleCloseToTray,
        setHideTaskbarIcon: state.handleToggleHideTaskbarIcon,
        setUiZoom: state.handleToggleUiZoom,
        setUiZoomStep: state.handleSetUiZoomStep,
        setWallpaperMode: state.handleToggleWallpaperMode,
        setWallpaperDock: state.handleToggleWallpaperMacAutohideDock,
    })));
    const chrome = usePlayerChromeSettingsStore(useShallow(state => ({
        titlebarSide: state.titlebarSide,
        setTitlebarSide: state.handleSetTitlebarSide,
        hideFullscreenButton: state.hideFullscreenButton,
        nativeMacFullscreen: state.useNativeMacFullscreenButton,
        trafficLights: state.useNativeMacTrafficLights,
        setHideFullscreenButton: state.handleToggleHideFullscreenButton,
        setNativeMacFullscreen: state.handleToggleNativeMacFullscreenButton,
        setTrafficLights: state.handleToggleNativeMacTrafficLights,
    })));

    return (
        <>
            <Group def={WINDOW}>
                <Row option={O.uiZoom} hint={t('options.uiZoomDesc')}>
                    <Toggle checked={desktop.uiZoomEnabled} onChange={desktop.setUiZoom} />
                </Row>
                <Reveal when={desktop.uiZoomEnabled}>
                    <Row sub option={O.uiZoomStep}>
                        <Select
                            value={String(desktop.uiZoomStep)}
                            options={UI_ZOOM_CHOICES}
                            onChange={(value) => {
                                const step = readUiZoomStep(value);
                                if (step) desktop.setUiZoomStep(step);
                            }}
                        />
                    </Row>
                </Reveal>
                <Row option={O.minimizeToTray}>
                    <Toggle checked={desktop.minimizeToTray} onChange={desktop.setMinimizeToTray} />
                </Row>
                <Row option={O.closeToTray} hint={t('options.closeToTrayDesc')}>
                    <Toggle checked={desktop.closeToTray} onChange={desktop.setCloseToTray} />
                </Row>
                <Row option={O.hideTaskbarIcon}>
                    <Toggle checked={desktop.hideTaskbarIcon} onChange={desktop.setHideTaskbarIcon} />
                </Row>
                <Reveal when={desktop.hideTaskbarIcon}>
                    <Row sub notice={t('options.hideTaskbarIconNotice')} />
                </Reveal>
                <Row option={O.titlebarSide} hint={t('options.titlebarSideDesc')}>
                    <Segmented value={chrome.titlebarSide} onChange={chrome.setTitlebarSide}
                        options={[{ value: 'left', label: t('options.titlebarSideLeft') }, { value: 'right', label: t('options.titlebarSideRight') }]} />
                </Row>
                <Row option={O.hideFullscreenButton} hint={t('options.hideFullscreenButtonDesc')}>
                    <Toggle checked={chrome.hideFullscreenButton} onChange={chrome.setHideFullscreenButton} />
                </Row>
                {IS_MAC && (
                    <Row option={O.nativeMacFullscreen} hint={t('options.useNativeMacFullscreenButtonDesc')}>
                        <Toggle checked={chrome.nativeMacFullscreen} onChange={chrome.setNativeMacFullscreen} />
                    </Row>
                )}
                {IS_MAC && (
                    <Row
                        option={O.nativeMacTrafficLights}
                        hint={t('options.useNativeMacTrafficLightsDesc')}
                        note={t('options.useNativeMacTrafficLightsNotice')}
                    >
                        <Toggle checked={chrome.trafficLights} onChange={chrome.setTrafficLights} />
                    </Row>
                )}
                {HAS_WALLPAPER_MODE && (
                    <Row
                        option={O.wallpaperMode}
                        hint={t('options.wallpaperModeDesc')}
                        note={IS_MAC ? t('options.wallpaperModeMacPermissionHint') : undefined}
                    >
                        {/* Turning it on asks first: the store opens the app's confirmation. */}
                        <Toggle checked={desktop.wallpaperMode} onChange={desktop.setWallpaperMode} />
                    </Row>
                )}
                {/* Not in a Reveal: the choice also holds for the next time wallpaper mode is entered. */}
                {HAS_WALLPAPER_MODE && <WallpaperDisplayRow option={O.wallpaperDisplay} />}
                {IS_MAC && (
                    // Not in a Reveal: it also holds for the next time wallpaper mode is entered.
                    <Row sub option={O.wallpaperDock}>
                        <Toggle checked={desktop.wallpaperDock} onChange={desktop.setWallpaperDock} />
                    </Row>
                )}
            </Group>
        </>
    );
};

export default DesktopPage;
