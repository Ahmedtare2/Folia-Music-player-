import { useMemo, useRef, useState } from 'react';
import { Check, FileAudio, Loader2, Piano, Search, X } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import type { LocalSong } from '../../types';
import type { LocalLibraryAssignment } from '../../types/localLibrary';
import { getLocalCoverAssetUrl } from '../../services/localCoverAssetUrl';
import { applyOnlineMetadataCandidate, useImportedSnapshotForLocalSong } from '../../services/localSongMetadataMatchService';
import { setLocalSongPureMusicMark } from '../../services/localSongMatchSelectionService';
import { setStatusMessage } from '../../stores/useStatusMessageStore';
import {
    buildLocalSongMetadataSearchQuery,
    buildLocalSongMetadataSearchTarget,
    searchOnlineMetadata,
    type OnlineMetadataCandidate,
    type OnlineMetadataSource,
} from '../../services/onlineMetadataSearchService';
import { DurationMatchBadge } from './DurationMatchBadge';
import { getSizedCoverUrl } from '../../utils/coverUrl';
import { useConfirmDialog } from '../shared/useConfirmDialog';
import { useCrossSourceParticipants } from '../../hooks/useCrossSourceParticipants';
import { omni } from '../../services/onlineMusic/omni';

// src/components/modal/LocalSongMetadataMatchDialog.tsx
// Lets the user search one provider and independently choose its metadata bundle and cover.

// The names the source tabs have always shown; a source without one shows its platform's name.
const SOURCE_LABEL_KEYS: Readonly<Record<string, string>> = {
    netease: 'localMusic.neteaseSource',
    qq: 'localMusic.qqSource',
    kugou: 'localMusic.kugouSource',
};

interface LocalSongMetadataMatchDialogProps {
    song: LocalSong;
    assignment?: LocalLibraryAssignment;
    isDaylight: boolean;
    onClose: () => void;
    onChanged: () => Promise<void>;
}

export const LocalSongMetadataMatchDialog = ({ song, assignment, isDaylight, onClose, onChanged }: LocalSongMetadataMatchDialogProps) => {
    const { t } = useTranslation();
    // The sources that can match a local song now (crossSource.ts); one that is not there has no tab. The tab
    // chosen falls back to the first while its source is away, and is the chosen one again once it is back.
    const sources = useCrossSourceParticipants('metadata').ready as OnlineMetadataSource[];
    const [chosenSource, setSource] = useState<OnlineMetadataSource | null>(null);
    const source: OnlineMetadataSource | undefined = chosenSource && sources.includes(chosenSource) ? chosenSource : sources.at(0);
    const [query, setQuery] = useState(() => buildLocalSongMetadataSearchQuery(song));
    const [results, setResults] = useState<OnlineMetadataCandidate[]>([]);
    const [selected, setSelected] = useState<OnlineMetadataCandidate | null>(null);
    const [searching, setSearching] = useState(false);
    const [applying, setApplying] = useState(false);
    const [restoringLocalInfo, setRestoringLocalInfo] = useState(false);
    const [markingPureMusic, setMarkingPureMusic] = useState(false);
    const [useOnlineMetadata, setUseOnlineMetadata] = useState(song.titleOrigin !== 'import');
    const [useOnlineCover, setUseOnlineCover] = useState(song.useOnlineCover ?? !song.localCoverAssetId);
    const localCoverUrl = getLocalCoverAssetUrl(song.localCoverAssetId, 512);
    const requestIdRef = useRef(0);
    const { ask: askConfirm, dialog: confirmDialog } = useConfirmDialog(isDaylight);
    const target = useMemo(() => buildLocalSongMetadataSearchTarget(song), [song]);
    const currentTitle = song.title;
    const currentArtist = (song.titleOrigin !== 'import'
        ? song.onlineMetadata?.artists.map(artist => artist.name).join(', ')
        : song.importedMetadata.artistNames.join(', ')) || t('localMusic.unknownArtist');
    const currentAlbum = (song.titleOrigin !== 'import'
        ? song.onlineMetadata?.album?.name
        : song.importedMetadata.albumName) || t('localMusic.unknownAlbum');
    const currentCoverUrl = song.useOnlineCover && song.onlineMetadata?.coverUrl
        ? song.onlineMetadata.coverUrl
        : localCoverUrl;
    const selectedArtist = selected?.artists.map(artist => artist.name).join(', ') || '';
    const previewTitle = useOnlineMetadata && selected?.title ? selected.title : currentTitle;
    const previewArtist = useOnlineMetadata && selectedArtist ? selectedArtist : currentArtist;
    const previewAlbum = useOnlineMetadata && selected?.album?.name ? selected.album.name : currentAlbum;
    const previewCoverUrl = useOnlineCover && selected?.coverUrl ? selected.coverUrl : currentCoverUrl;

    const search = async () => {
        const safeQuery = query.trim();
        // No source can match a local song now (none of them is there): nothing to ask.
        if (!safeQuery || !source) return;
        const requestId = ++requestIdRef.current;
        setSearching(true);
        setSelected(null);
        try {
            const next = await searchOnlineMetadata(source, safeQuery, target);
            if (requestId === requestIdRef.current) setResults(next);
        } catch (error) {
            console.error('[LocalMusic] Manual metadata search failed:', error);
            if (requestId === requestIdRef.current) setResults([]);
        } finally {
            if (requestId === requestIdRef.current) setSearching(false);
        }
    };
    const apply = async () => {
        if (!selected) return;
        const replacesProtectedArtist = selected.artists.length > 0 && ['manual', 'split'].includes(assignment?.artistOrigin || '');
        const replacesProtectedAlbum = Boolean(selected.album) && ['manual', 'split'].includes(assignment?.albumOrigin || '');
        if (useOnlineMetadata && (replacesProtectedArtist || replacesProtectedAlbum)
            && !await askConfirm({
                title: t('localMusic.applyMetadataMatch'),
                description: t('localMusic.replaceProtectedEntityConfirm'),
                confirmText: t('localMusic.applyMetadataMatch'),
                confirmVariant: 'danger',
            })) return;
        setApplying(true);
        try {
            const applied = await applyOnlineMetadataCandidate(song, selected, {
                mode: 'manual',
                useOnlineMetadata,
                useOnlineCover,
            });
            await onChanged();
            if (applied.coverAttempted && !applied.coverCached) {
                setStatusMessage({ type: 'error', text: t('localMusic.coverCacheFailed') });
            }
            onClose();
        } catch (error) {
            console.error('[LocalMusic] Failed to apply manual metadata match:', error);
        } finally {
            setApplying(false);
        }
    };
    const useLocalInfo = async () => {
        setRestoringLocalInfo(true);
        try {
            await useImportedSnapshotForLocalSong(song.id);
            await onChanged();
            onClose();
        } catch (error) {
            console.error('[LocalMusic] Failed to restore imported snapshot:', error);
        } finally {
            setRestoringLocalInfo(false);
        }
    };
    // 标记 / 取消纯音乐：只改歌词的自动匹配，元数据与封面不动；正在播放的这首由 onChanged 里的刷新就地换歌词。
    const togglePureMusicMark = async () => {
        const marked = !song.markedPureMusic;
        setMarkingPureMusic(true);
        try {
            await setLocalSongPureMusicMark(song.id, marked);
            await onChanged();
            setStatusMessage({ type: 'success', text: t(marked ? 'status.markedPureMusic' : 'status.unmarkedPureMusic') });
            onClose();
        } catch (error) {
            console.error('[LocalMusic] Failed to toggle the instrumental mark:', error);
            setStatusMessage({ type: 'error', text: t('localMusic.pureMusicMarkFailed') });
        } finally {
            setMarkingPureMusic(false);
        }
    };
    const busy = applying || restoringLocalInfo || markingPureMusic;
    const panelTheme = isDaylight ? 'border-black/10 bg-white text-zinc-900' : 'border-white/10 bg-zinc-950 text-white';

    return (
        <div data-folia-keyboard-window="true" className="fixed inset-0 z-[140] flex items-center justify-center bg-black/65 p-4">
            <div role="dialog" aria-modal="true" className={`${panelTheme} flex max-h-[82vh] w-full max-w-2xl flex-col overflow-hidden rounded-2xl border shadow-2xl`}>
                <header className="flex items-center justify-between border-b border-current/10 px-5 py-4">
                    <div className="min-w-0">
                        <h3 className="truncate text-lg font-bold">{t('localMusic.manualMetadataMatch')}</h3>
                        <p className="mt-1 truncate text-xs opacity-60">{song.title || song.importedMetadata.title}</p>
                        <div className="mt-1 flex min-w-0 items-center gap-2">
                            <span title={song.fileName} className="flex min-w-0 items-center gap-1 text-[11px] opacity-45">
                                <FileAudio size={12} className="shrink-0" />
                                <span className="shrink-0">{t('localMusic.filename')}:</span>
                                <span className="truncate">{song.fileName}</span>
                            </span>
                            {song.noAutoMatch && (
                                <span className="shrink-0 rounded-full bg-amber-500/15 px-2 py-0.5 text-[10px] font-bold text-amber-500">
                                    {t('localMusic.localInfoBadge')}
                                </span>
                            )}
                            {song.markedPureMusic && (
                                <span className="shrink-0 rounded-full bg-violet-500/15 px-2 py-0.5 text-[10px] font-bold text-violet-500">
                                    {t('localMusic.statusPureMusic')}
                                </span>
                            )}
                        </div>
                    </div>
                    <button type="button" onClick={onClose} className="rounded-full p-2 hover:bg-current/10"><X size={19} /></button>
                </header>
                <div className="flex min-h-0 flex-1 flex-col gap-4 p-5">
                    <div className="flex gap-2">
                        {sources.map(item => (
                            <button key={item} type="button" onClick={() => { setSource(item); setResults([]); setSelected(null); }} className={`rounded-full px-4 py-2 text-xs font-bold ${source === item ? 'bg-blue-500 text-white' : 'bg-current/10'}`}>
                                {SOURCE_LABEL_KEYS[item] ? t(SOURCE_LABEL_KEYS[item]) : omni.getProviderLabel(item)}
                            </button>
                        ))}
                    </div>
                    <form onSubmit={event => { event.preventDefault(); void search(); }} className="flex gap-2">
                        <label className="flex min-w-0 flex-1 items-center gap-2 rounded-xl border border-current/10 px-3">
                            <Search size={15} className="opacity-45" />
                            <input value={query} onChange={event => setQuery(event.target.value)} className="min-w-0 flex-1 bg-transparent py-3 text-sm outline-none" />
                        </label>
                        <button type="submit" disabled={searching || !query.trim()} className="rounded-xl bg-blue-500 px-4 text-sm font-bold text-white disabled:opacity-40">
                            {searching ? <Loader2 size={16} className="animate-spin" /> : t('localMusic.search')}
                        </button>
                    </form>
                    <div className="min-h-48 flex-1 space-y-2 overflow-y-auto custom-scrollbar">
                        {results.map(candidate => (
                            <button key={`${candidate.source}:${candidate.songId}`} type="button" onClick={() => { setSelected(candidate); if (!candidate.coverUrl) setUseOnlineCover(false); }} className={`flex w-full items-center gap-3 rounded-xl border p-3 text-left ${selected === candidate ? 'border-blue-500 bg-blue-500/10' : 'border-current/10 hover:bg-current/5'}`}>
                                <span className="min-w-0 flex-1">
                                    <span className="block truncate text-sm font-bold">{candidate.title}</span>
                                    <span className="block truncate text-xs opacity-55">{candidate.artists.map(artist => artist.name).join(', ')} · {candidate.album?.name || t('localMusic.unknownAlbum')}</span>
                                </span>
                                <span className="flex shrink-0 items-center gap-2">
                                    <DurationMatchBadge matched={candidate.durationMatched} />
                                    <span className="text-xs font-bold opacity-50">{candidate.score}%</span>
                                </span>
                                {selected === candidate && <Check size={17} className="text-blue-500" />}
                            </button>
                        ))}
                        {!searching && results.length === 0 && <div className="flex h-48 items-center justify-center text-sm opacity-40">{t('localMusic.enterMetadataSearch')}</div>}
                    </div>
                    {selected && (
                        <div className="grid gap-3 sm:grid-cols-2">
                            <div className="rounded-xl border border-current/10 p-3">
                                <div className="mb-2 text-[11px] font-bold uppercase tracking-wider opacity-45">{t('localMusic.currentSongInfo')}</div>
                                <div className="flex gap-3">
                                    <div className="h-14 w-14 shrink-0 overflow-hidden rounded-lg bg-current/10">
                                        {currentCoverUrl && <img src={getSizedCoverUrl(currentCoverUrl, 512)} alt="" decoding="async" className="h-full w-full object-cover" />}
                                    </div>
                                    <div className="min-w-0 text-xs">
                                        <div className="truncate font-bold">{currentTitle}</div>
                                        <div className="truncate opacity-65">{currentArtist}</div>
                                        <div className="truncate opacity-45">{currentAlbum}</div>
                                    </div>
                                </div>
                            </div>
                            <div className="rounded-xl border border-blue-500/30 bg-blue-500/5 p-3">
                                <div className="mb-2 text-[11px] font-bold uppercase tracking-wider text-blue-500">{t('localMusic.matchResultPreview')}</div>
                                <div className="flex gap-3">
                                    <div className="h-14 w-14 shrink-0 overflow-hidden rounded-lg bg-current/10">
                                        {previewCoverUrl && <img src={getSizedCoverUrl(previewCoverUrl, 512)} alt="" decoding="async" className="h-full w-full object-cover" />}
                                    </div>
                                    <div className="min-w-0 text-xs">
                                        <div className="truncate font-bold">{previewTitle}</div>
                                        <div className="truncate opacity-65">{previewArtist}</div>
                                        <div className="truncate opacity-45">{previewAlbum}</div>
                                    </div>
                                </div>
                            </div>
                            <button type="button" role="switch" aria-checked={useOnlineMetadata} onClick={() => setUseOnlineMetadata(value => !value)} className={`flex items-center justify-between rounded-xl border px-4 py-3 text-left ${useOnlineMetadata ? 'border-blue-500 bg-blue-500/10' : 'border-current/10'}`}>
                                <span>
                                    <span className="block text-sm font-bold">{t('localMusic.useOnlineMetadataResult')}</span>
                                    <span className="block text-xs opacity-50">{t('localMusic.metadataBundleHint')}</span>
                                </span>
                                {useOnlineMetadata && <Check size={18} className="text-blue-500" />}
                            </button>
                            <button type="button" role="switch" aria-checked={useOnlineCover} disabled={!selected.coverUrl} onClick={() => setUseOnlineCover(value => !value)} className={`flex items-center justify-between rounded-xl border px-4 py-3 text-left disabled:opacity-35 ${useOnlineCover ? 'border-blue-500 bg-blue-500/10' : 'border-current/10'}`}>
                                <span>
                                    <span className="block text-sm font-bold">{t('localMusic.useOnlineCoverResult')}</span>
                                    {!selected.coverUrl && <span className="block text-xs opacity-50">{t('localMusic.candidateHasNoCover')}</span>}
                                </span>
                                {useOnlineCover && selected.coverUrl && <Check size={18} className="text-blue-500" />}
                            </button>
                        </div>
                    )}
                    <div className="flex flex-wrap items-center justify-between gap-3">
                        <div className="flex flex-wrap items-center gap-3">
                            <button type="button" disabled={busy} onClick={() => void useLocalInfo()} className="flex items-center gap-2 rounded-xl border border-amber-500/40 bg-amber-500/10 px-4 py-3 text-sm font-bold text-amber-500 disabled:opacity-35">
                                {restoringLocalInfo && <Loader2 size={15} className="animate-spin" />}{t('localMusic.dontUseOnlineMetadata')}
                            </button>
                            <button
                                type="button"
                                disabled={busy}
                                onClick={() => void togglePureMusicMark()}
                                aria-pressed={Boolean(song.markedPureMusic)}
                                title={t('localMusic.markPureMusicHint')}
                                className={`flex items-center gap-2 rounded-xl border border-violet-500/40 px-4 py-3 text-sm font-bold text-violet-500 disabled:opacity-35 ${song.markedPureMusic ? 'bg-violet-500/25' : 'bg-violet-500/10'}`}
                            >
                                {markingPureMusic ? <Loader2 size={15} className="animate-spin" /> : <Piano size={15} />}
                                {t(song.markedPureMusic ? 'localMusic.unmarkPureMusic' : 'localMusic.markPureMusic')}
                            </button>
                        </div>
                        <button type="button" disabled={!selected || busy} onClick={() => void apply()} className="ml-auto flex items-center justify-center gap-2 rounded-xl bg-blue-500 px-4 py-3 text-sm font-bold text-white disabled:opacity-35">
                            {applying && <Loader2 size={15} className="animate-spin" />}{t('localMusic.applyMetadataMatch')}
                        </button>
                    </div>
                </div>
            </div>
            {confirmDialog}
        </div>
    );
};
