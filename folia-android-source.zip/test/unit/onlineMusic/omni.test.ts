import { afterEach, describe, expect, it, vi } from 'vitest';
import { saveProviderAccountSnapshot } from '@/services/onlineMusic/providerAccountCache';
import { omni } from '@/services/onlineMusic/omni';
import { registerOnlineMusicProvider, unregisterOnlineMusicProvider } from '@/services/onlineMusic/providerRegistry';
import { useOnlineProviderAccountStore } from '@/stores/useOnlineProviderAccountStore';
import type { UnifiedSong } from '@/types';
import type { OnlineMusicProvider, ProviderCapabilities, ProviderCollection } from '@/types/onlineMusic';
import { onlineFailureOf } from '@/services/onlineMusic/failure/onlineFailureCase';
import { installOmniResultHooks } from '@/services/hostExtensionHooks';

// test/unit/onlineMusic/omni.test.ts

vi.mock('@/services/onlineMusic/providerAccountCache', async importOriginal => ({
    ...(await importOriginal<typeof import('@/services/onlineMusic/providerAccountCache')>()),
    saveProviderAccountSnapshot: vi.fn(async () => ({
        version: 1 as const,
        savedAt: 1,
        user: { id: 'user', nickname: 'Listener' },
        collections: [],
        likedSongIds: [],
    })),
}));

const providerId = 'omni-test';
const otherProviderId = 'omni-resource-test';
const missingProviderId = 'omni-missing-provider-test';
const capabilities: ProviderCapabilities = {
    search: true, playback: true, lyrics: false, auth: false, userLibrary: false,
    playlists: false, albums: false, artists: false, recommendations: false,
    mutations: false, wordByWordLyrics: false,
};
const song = (owner: string, mediaId = '1'): UnifiedSong => ({
    id: mediaId,
    name: `${owner}:${mediaId}`,
    artists: [],
    album: { id: '', name: '' },
    durationMs: 1,
    sourceRef: { kind: 'online', providerId: owner, mediaId },
});

const provider = (id: string, search: OnlineMusicProvider['search']): OnlineMusicProvider => ({
    id,
    displayName: id,
    capabilities,
    normalizeSong: raw => song(id, String((raw as { id?: string }).id || '1')),
    search,
    playback: {
        getSongDetail: async mediaId => song(id, String(mediaId)),
        getAudioSource: async target => ({ url: `https://${id}/${target.sourceRef?.mediaId}`, fetchedAt: 1, quality: 'standard' }),
    },
});

afterEach(() => {
    unregisterOnlineMusicProvider(providerId);
    unregisterOnlineMusicProvider(otherProviderId);
    useOnlineProviderAccountStore.getState().setActiveProviderId('netease');
    omni.invalidateActiveRequests();
});

describe('omni routing', () => {
    it('falls back from a persisted provider missing in the current build', () => {
        useOnlineProviderAccountStore.getState().setActiveProviderId(missingProviderId);

        expect(omni.getActiveProviderSummary()?.providerId).toBe('netease');
        expect(omni.getActiveCapabilities()).toEqual(omni.getProviderCapabilities('netease'));
        expect(useOnlineProviderAccountStore.getState().activeProviderId).toBe(missingProviderId);
    });

    it('marks a provider without auth as one that needs no account', () => {
        registerOnlineMusicProvider(provider(providerId, { searchSongs: async () => ({ items: [], hasMore: false, nextOffset: 0 }) }));
        const summaries = omni.getProviderSummaries();

        expect(summaries.find(summary => summary.providerId === providerId)?.requiresAccount).toBe(false);
        expect(summaries.find(summary => summary.providerId === 'netease')?.requiresAccount).toBe(true);
    });

    it('reports songs from unavailable providers as unplayable without routing them elsewhere', () => {
        expect(omni.canPlaySong(song(missingProviderId))).toBe(false);
    });

    it('routes ordinary search through the active provider and resources through their owner', async () => {
        const activeSearch = vi.fn(async () => ({ items: [song(providerId)], hasMore: false, nextOffset: 1 }));
        registerOnlineMusicProvider(provider(providerId, { searchSongs: activeSearch }));
        registerOnlineMusicProvider(provider(otherProviderId, { searchSongs: async () => ({ items: [], hasMore: false, nextOffset: 0 }) }));
        useOnlineProviderAccountStore.getState().setActiveProviderId(providerId);

        await expect(omni.searchSongs('query', { limit: 10, offset: 0 })).resolves.toMatchObject({ items: [{ name: `${providerId}:1` }] });
        await expect(omni.getAudioSource(song(otherProviderId, '9'), 'standard')).resolves.toMatchObject({ url: `https://${otherProviderId}/9` });
        expect(activeSearch).toHaveBeenCalledWith('query', 10, 0);
    });

    it('forwards normalized provider ReplayGain metadata through the audio facade', async () => {
        registerOnlineMusicProvider({
            ...provider(providerId, { searchSongs: async () => ({ items: [], hasMore: false, nextOffset: 0 }) }),
            playback: {
                getSongDetail: async mediaId => song(providerId, String(mediaId)),
                getAudioSource: async target => ({
                    url: `https://${providerId}/${target.sourceRef?.mediaId}`,
                    fetchedAt: 1,
                    quality: 'standard',
                    replayGain: { trackGain: -4.5 },
                }),
            },
        });

        await expect(omni.getAudioSource(song(providerId, 'gain-song'), 'standard')).resolves.toMatchObject({
            replayGain: { trackGain: -4.5 },
        });
    });

    it('routes chorus range lookup through the song owner', async () => {
        const getChorusRanges = vi.fn(async () => [{ startTime: 10, endTime: 20 }]);
        registerOnlineMusicProvider({
            ...provider(providerId, { searchSongs: async () => ({ items: [], hasMore: false, nextOffset: 0 }) }),
            lyrics: {
                getLyrics: async () => ({ lyrics: null, isPureMusic: false }),
                getChorusRanges,
            },
        });

        const target = song(providerId, 'chorus-song');
        await expect(omni.getChorusRanges(target)).resolves.toEqual([{ startTime: 10, endTime: 20 }]);
        expect(getChorusRanges).toHaveBeenCalledWith('chorus-song');
    });

    it('rejects a late active-provider result after invalidation', async () => {
        let resolveSearch!: (value: { items: UnifiedSong[]; hasMore: false; nextOffset: number }) => void;
        registerOnlineMusicProvider(provider(providerId, {
            searchSongs: () => new Promise(resolve => { resolveSearch = resolve; }),
        }));
        useOnlineProviderAccountStore.getState().setActiveProviderId(providerId);
        const pending = omni.searchSongs('late', { limit: 10, offset: 0 });
        omni.invalidateActiveRequests();
        resolveSearch({ items: [song(providerId)], hasMore: false, nextOffset: 1 });
        await expect(pending).rejects.toMatchObject({ name: 'AbortError' });
    });

    it('reads provider song likes through the Omni facade', () => {
        const target = song(providerId, 'liked-song');
        useOnlineProviderAccountStore.getState().updateAccount(providerId, {
            likedSongIds: ['liked-song'],
        });

        expect(omni.isSongLiked(target)).toBe(true);
        expect(omni.isSongLiked(song(providerId, 'other-song'))).toBe(false);
        expect(omni.isSongLiked({ ...target, sourceRef: { kind: 'local', mediaId: 'liked-song' } })).toBe(false);
    });

    it('returns only the owning provider playlists for an online song', () => {
        const playlist: ProviderCollection = {
            providerId,
            id: 'kugou-playlist',
            name: 'KuGou playlist',
            type: 'playlist',
        };
        useOnlineProviderAccountStore.getState().updateAccount(providerId, {
            collections: [playlist, { ...playlist, id: 'kugou-album', type: 'album' }],
        });
        registerOnlineMusicProvider({
            ...provider(providerId, { searchSongs: async () => ({ items: [], hasMore: false, nextOffset: 0 }) }),
            capabilities: { ...capabilities, mutations: true, playlistTrackMutations: true },
            mutations: { updatePlaylistTracks: async () => undefined },
        });

        expect(omni.getPlaylistsForSong(song(providerId))).toEqual([playlist]);
        expect(omni.getPlaylistsForSong({ ...song(providerId), sourceRef: { kind: 'local', mediaId: 'local-song' } })).toEqual([]);
    });

    it('does not expose read-only provider playlists as mutation targets', async () => {
        const playlist: ProviderCollection = {
            providerId,
            id: 'read-only-playlist',
            name: 'Read-only playlist',
            type: 'playlist',
        };
        registerOnlineMusicProvider({
            ...provider(providerId, { searchSongs: async () => ({ items: [], hasMore: false, nextOffset: 0 }) }),
            capabilities: { ...capabilities, userLibrary: true, playlists: true },
            library: {
                getUserPlaylists: async () => ({ items: [playlist], hasMore: false, nextOffset: 1 }),
            },
        });
        useOnlineProviderAccountStore.getState().updateAccount(providerId, { collections: [playlist] });

        expect(omni.canAddSongToPlaylist(song(providerId))).toBe(false);
        expect(omni.canEditCollectionTracks(playlist)).toBe(false);
        expect(omni.canSubscribeCollection(playlist)).toBe(false);
        expect(omni.getPlaylistsForSong(song(providerId))).toEqual([]);
        expect(omni.canDislikeSong(song(providerId))).toBe(false);
        await expect(omni.subscribe(playlist, true)).rejects.toMatchObject({ code: 'unsupported' });
        await expect(omni.dislikeSong(song(providerId))).rejects.toMatchObject({ code: 'unsupported' });
    });

    it('lets a provider hide playlists that cannot accept track mutations', () => {
        const addable: ProviderCollection = {
            providerId,
            id: 'addable',
            name: 'Addable',
            type: 'playlist',
        };
        const hidden: ProviderCollection = {
            providerId,
            id: 'hidden',
            name: 'Hidden',
            type: 'playlist',
        };
        registerOnlineMusicProvider({
            ...provider(providerId, { searchSongs: async () => ({ items: [], hasMore: false, nextOffset: 0 }) }),
            capabilities: { ...capabilities, mutations: true, playlistTrackMutations: true },
            mutations: {
                canAddToPlaylist: playlist => playlist.id === addable.id,
                updatePlaylistTracks: async () => undefined,
            },
        });
        useOnlineProviderAccountStore.getState().updateAccount(providerId, {
            collections: [addable, hidden],
        });

        expect(omni.getPlaylistsForSong(song(providerId))).toEqual([addable]);
    });

    it('refreshes the owning provider playlist cache through Omni', async () => {
        const playlist: ProviderCollection = {
            providerId,
            id: 'refreshed-playlist',
            name: 'Refreshed playlist',
            type: 'playlist',
        };
        const getUserPlaylists = vi.fn(async () => ({ items: [playlist], hasMore: false, nextOffset: 1 }));
        registerOnlineMusicProvider({
            ...provider(providerId, { searchSongs: async () => ({ items: [], hasMore: false, nextOffset: 0 }) }),
            library: { getUserPlaylists },
        });
        useOnlineProviderAccountStore.getState().updateAccount(providerId, {
            user: { id: 'user', nickname: 'User' },
            collections: [{ providerId, id: 'cloud', name: 'Cloud', type: 'cloud' }],
        });

        await expect(omni.refreshProviderPlaylists(providerId)).resolves.toEqual([playlist]);

        expect(getUserPlaylists).toHaveBeenCalledWith('user', 50, 0);
        expect(useOnlineProviderAccountStore.getState().accounts[providerId]?.collections).toEqual([
            playlist,
            { providerId, id: 'cloud', name: 'Cloud', type: 'cloud' },
        ]);
    });

    it('toggles a song through its owning provider and updates only that provider cache', async () => {
        const kugouLike = vi.fn(async () => undefined);
        const neteaseLike = vi.fn(async () => undefined);
        registerOnlineMusicProvider({
            ...provider(providerId, { searchSongs: async () => ({ items: [], hasMore: false, nextOffset: 0 }) }),
            capabilities: { ...capabilities, mutations: true, likes: true },
            mutations: { likeSong: kugouLike },
        });
        registerOnlineMusicProvider({
            ...provider(otherProviderId, { searchSongs: async () => ({ items: [], hasMore: false, nextOffset: 0 }) }),
            capabilities: { ...capabilities, mutations: true, likes: true },
            mutations: { likeSong: neteaseLike },
        });
        useOnlineProviderAccountStore.getState().updateAccount(providerId, { likedSongIds: ['existing'] });

        const target = song(providerId, 'kugou-song');
        await expect(omni.toggleSongLike(target)).resolves.toBe(true);

        expect(kugouLike).toHaveBeenCalledWith(target, true);
        expect(neteaseLike).not.toHaveBeenCalled();
        expect(useOnlineProviderAccountStore.getState().accounts[providerId]?.likedSongIds).toEqual(['existing', 'kugou-song']);
    });

    it('keeps readable likes visible without exposing an unsupported like mutation', async () => {
        registerOnlineMusicProvider({
            ...provider(providerId, { searchSongs: async () => ({ items: [], hasMore: false, nextOffset: 0 }) }),
            capabilities: { ...capabilities, likes: true },
            library: {
                getUserPlaylists: async () => ({ items: [], hasMore: false, nextOffset: 0 }),
                getLikedSongIds: async () => ({ ids: ['liked-song'], whole: true }),
            },
        });
        const target = song(providerId, 'liked-song');
        useOnlineProviderAccountStore.getState().updateAccount(providerId, { likedSongIds: ['liked-song'] });

        expect(omni.isSongLiked(target)).toBe(true);
        expect(omni.canLikeSong(target)).toBe(false);
        await expect(omni.toggleSongLike(target)).rejects.toMatchObject({ code: 'unsupported' });
    });

    it('routes playlist track updates through the collection owner', async () => {
        const updateTracks = vi.fn(async () => undefined);
        const refreshedPlaylist: ProviderCollection = {
            providerId,
            id: 'kugou-playlist',
            name: 'Refreshed KuGou playlist',
            type: 'playlist',
        };
        const getUserPlaylists = vi.fn(async () => ({ items: [refreshedPlaylist], hasMore: false, nextOffset: 1 }));
        registerOnlineMusicProvider({
            ...provider(providerId, { searchSongs: async () => ({ items: [], hasMore: false, nextOffset: 0 }) }),
            capabilities: { ...capabilities, mutations: true, playlistTrackMutations: true },
            mutations: { updatePlaylistTracks: updateTracks },
            library: { getUserPlaylists },
        });
        const collection: ProviderCollection = {
            providerId,
            id: 'kugou-playlist',
            name: 'KuGou playlist',
            type: 'playlist',
        };
        const target = song(providerId, 'kugou-song');
        useOnlineProviderAccountStore.getState().updateAccount(providerId, {
            user: { id: 'user', nickname: 'User' },
        });

        await omni.addSongToPlaylist(target, collection);

        expect(updateTracks).toHaveBeenCalledWith('add', collection, [target]);
        expect(getUserPlaylists).toHaveBeenCalledWith('user', 50, 0);
    });

    it('rejects a playlist that its provider marks as non-mutable', async () => {
        const updateTracks = vi.fn(async () => undefined);
        registerOnlineMusicProvider({
            ...provider(providerId, { searchSongs: async () => ({ items: [], hasMore: false, nextOffset: 0 }) }),
            capabilities: { ...capabilities, mutations: true, playlistTrackMutations: true },
            mutations: {
                canAddToPlaylist: () => false,
                updatePlaylistTracks: updateTracks,
            },
        });

        await expect(omni.addSongToPlaylist(song(providerId), {
            providerId,
            id: 'hidden',
            name: 'Hidden',
            type: 'playlist',
        })).rejects.toMatchObject({ code: 'unsupported' });
        expect(updateTracks).not.toHaveBeenCalled();
    });

    it('routes a listening report to the provider that owns the song', async () => {
        const reportPlayback = vi.fn(async () => undefined);
        registerOnlineMusicProvider({
            ...provider(providerId, { searchSongs: async () => ({ items: [], hasMore: false, nextOffset: 0 }) }),
            capabilities: { ...capabilities, playbackReports: true },
            playbackReports: { reportPlayback },
        });
        registerOnlineMusicProvider(provider(otherProviderId, { searchSongs: async () => ({ items: [], hasMore: false, nextOffset: 0 }) }));
        useOnlineProviderAccountStore.getState().setActiveProviderId(otherProviderId);

        const target = song(providerId, '5');
        expect(omni.canReportPlayback(target)).toBe(true);
        await omni.reportPlayback(target, { playedSeconds: 45, totalSeconds: 240 });

        expect(reportPlayback).toHaveBeenCalledWith(target, { playedSeconds: 45, totalSeconds: 240 });
    });

    it('refuses a listening report for a provider that does not declare the capability', async () => {
        registerOnlineMusicProvider(provider(providerId, { searchSongs: async () => ({ items: [], hasMore: false, nextOffset: 0 }) }));

        const target = song(providerId, '5');
        expect(omni.canReportPlayback(target)).toBe(false);
        await expect(omni.reportPlayback(target, { playedSeconds: 45 })).rejects.toMatchObject({ code: 'unsupported' });
    });

    it('takes no report of a song its provider says it cannot vouch for', () => {
        registerOnlineMusicProvider({
            ...provider(providerId, { searchSongs: async () => ({ items: [], hasMore: false, nextOffset: 0 }) }),
            capabilities: { ...capabilities, playbackReports: true },
            playbackReports: { canReport: target => target.id !== '6', reportPlayback: async () => {} },
        });

        expect(omni.canReportPlayback(song(providerId, '5'))).toBe(true);
        expect(omni.canReportPlayback(song(providerId, '6'))).toBe(false);
    });

    it('answers false rather than throwing for a song no online provider owns', () => {
        const localSong = { ...song(providerId), sourceRef: { kind: 'local', mediaId: 'local-1' } } as UnifiedSong;

        expect(omni.canReportPlayback(localSong)).toBe(false);
    });
});

// The media cache keeps the level a copy was fetched at, and asks for it by the URL the bytes came
// from: the quality option may be moved between a URL being handed out and its bytes being saved.
describe('the level an audio URL was handed out at', () => {
    // A provider that tells two levels apart and puts the one it was asked for in its URL.
    const twoLevelProvider = (
        urlOf = (mediaId: string, quality: string) => `https://${providerId}/${mediaId}/${quality}`,
    ): OnlineMusicProvider => ({
        ...provider(providerId, { searchSongs: async () => ({ items: [], hasMore: false, nextOffset: 0 }) }),
        playback: {
            getSongDetail: async mediaId => song(providerId, String(mediaId)),
            audioQualityLevels: ['standard', 'high'],
            getAudioSource: async (target, quality) => ({
                url: urlOf(String(target.sourceRef?.mediaId), quality), fetchedAt: 1, quality,
            }),
        },
    });

    it('is the level the preference meant to the provider when that URL was asked for', async () => {
        registerOnlineMusicProvider(twoLevelProvider());

        const first = await omni.getAudioSource(song(providerId, 'a'), 'standard');
        // The option is moved while the first URL is still playing.
        const second = await omni.getAudioSource(song(providerId, 'a'), 'hires');

        expect(omni.levelOfAudioSource(first!.url)).toBe('standard');
        expect(omni.levelOfAudioSource(second!.url)).toBe('high');
    });

    it('is unknown for a URL no provider handed out', () => {
        expect(omni.levelOfAudioSource('blob:http://localhost/0b8f')).toBeUndefined();
        expect(omni.levelOfAudioSource('https://navidrome.test/rest/stream?id=1')).toBeUndefined();
    });

    // NetEase hands out http and playback upgrades it to https. A deck that has played out reports
    // its element's `currentSrc`, which is the URL as the parser writes it.
    it('is found by the spelling playback and the audio element hold', async () => {
        registerOnlineMusicProvider(twoLevelProvider(mediaId => `http://m1.music.126.net/${mediaId} live.mp3`));

        await omni.getAudioSource(song(providerId, 'b'), 'high');

        expect(omni.levelOfAudioSource('https://m1.music.126.net/b%20live.mp3')).toBe('high');
    });

    it('forgets the oldest URL once it holds 200', async () => {
        registerOnlineMusicProvider(twoLevelProvider());

        for (let index = 0; index <= 200; index += 1) {
            await omni.getAudioSource(song(providerId, `n${index}`), 'high');
        }

        expect(omni.levelOfAudioSource(`https://${providerId}/n0/high`)).toBeUndefined();
        expect(omni.levelOfAudioSource(`https://${providerId}/n1/high`)).toBe('high');
    });
});

// What a provider knows of a failed request is left on the error it threw, and the error goes on as it is.
describe('a request for audio or for a collection\'s tracks that fails', () => {
    const refused = new Error('E_SEVENTH 7');
    const failing = (describeFailure: OnlineMusicProvider['describeFailure']): OnlineMusicProvider => ({
        ...provider(providerId, { searchSongs: async () => ({ items: [], hasMore: false, nextOffset: 0 }) }),
        describeFailure,
        playback: {
            getSongDetail: async mediaId => song(providerId, String(mediaId)),
            getAudioSource: async () => { throw refused; },
        },
        catalog: { getPlaylistTracks: async () => { throw refused; } },
    });
    const playlist = { providerId, id: 'p1', name: 'P', type: 'playlist' } as ProviderCollection;

    afterEach(() => installOmniResultHooks(null));

    it('leaves the provider\'s description on the error, for the audio and for the tracks', async () => {
        const describeFailure = vi.fn((operation: string) => ({ code: '7', message: `${operation} refused` }));
        registerOnlineMusicProvider(failing(describeFailure));

        const audioError = await omni.getAudioSource(song(providerId), 'high').catch((error: unknown) => error);
        expect(audioError).toBe(refused);
        expect(onlineFailureOf({ operation: 'audio' }, { error: audioError })).toMatchObject({ case: 'refused', facts: { code: '7', message: 'audio refused' } });

        const tracksError = await omni.getCollectionTracks(playlist, { limit: 10, offset: 0 }).catch((error: unknown) => error);
        expect(tracksError).toBe(refused);
        expect(onlineFailureOf({ operation: 'collection' }, { error: tracksError }).facts.message).toBe('collection refused');
        expect(describeFailure.mock.calls.map(([operation]) => operation)).toEqual(['audio', 'collection']);
    });

    it('lets the error go on as it is when the provider\'s description throws', async () => {
        const warn = vi.spyOn(console, 'warn').mockImplementation(() => {});
        registerOnlineMusicProvider(failing(() => { throw new TypeError('bad'); }));

        await expect(omni.getAudioSource(song(providerId), 'high')).rejects.toBe(refused);
        expect(warn).toHaveBeenCalledWith('[Omni] describeFailure threw; the error goes on without a note', { operation: 'audio' }, expect.any(TypeError));
        warn.mockRestore();
    });

    // A mod's omni audio hook could always give a URL where the provider gave none; a provider that throws keeps that.
    it('asks the mods\' audio hook for a source when the provider threw, and throws only when it gives none', async () => {
        registerOnlineMusicProvider(failing(() => null));
        const hook = vi.fn(async (_song: unknown, source: unknown) => source as null);
        installOmniResultHooks({ audio: hook });
        await expect(omni.getAudioSource(song(providerId), 'high')).rejects.toBe(refused);
        expect(hook).toHaveBeenCalledWith(expect.objectContaining({ id: '1' }), null);

        installOmniResultHooks({ audio: async () => ({ url: 'https://mod.test/1.mp3', fetchedAt: 1, quality: 'standard' }) });
        await expect(omni.getAudioSource(song(providerId), 'high')).resolves.toMatchObject({ url: 'https://mod.test/1.mp3' });
    });
});

describe('omni like mutations', () => {
    const likeProvider = (likeSong: NonNullable<OnlineMusicProvider['mutations']>['likeSong']): OnlineMusicProvider => ({
        ...provider(providerId, { searchSongs: async () => ({ items: [], hasMore: false, nextOffset: 0 }) }),
        capabilities: { ...capabilities, mutations: true, likes: true },
        mutations: { likeSong },
    });

    afterEach(() => useOnlineProviderAccountStore.getState().clearAccount(providerId));

    const seedAccount = (state: { likedSongIds: string[] }) => {
        useOnlineProviderAccountStore.getState().updateAccount(providerId, {
            status: 'authenticated',
            user: { id: 'user', nickname: 'Listener' },
            ...state,
        });
    };

    it('keeps likedSongIds in sync when likeSong is called directly', async () => {
        registerOnlineMusicProvider(likeProvider(async () => undefined));
        seedAccount({ likedSongIds: ['7'] });

        await omni.likeSong(song(providerId, '7'), false);

        const account = useOnlineProviderAccountStore.getState().accounts[providerId];
        expect(account.likedSongIds).toEqual([]);
    });

    // What a provider needs beyond the song to like or unlike it (a row in its liked playlist) is
    // the adapter's own to keep.
    it('hands the provider the song and the state asked for, and nothing else', async () => {
        const likeSong = vi.fn(async () => undefined);
        registerOnlineMusicProvider(likeProvider(likeSong));
        seedAccount({ likedSongIds: ['7'] });

        const target = song(providerId, '7');
        await omni.likeSong(target, false);

        expect(likeSong).toHaveBeenCalledExactlyOnceWith(target, false);
    });

    it('leaves the liked state untouched when the mutation fails', async () => {
        registerOnlineMusicProvider(likeProvider(async () => { throw new Error('network'); }));
        seedAccount({ likedSongIds: ['7'] });

        await expect(omni.likeSong(song(providerId, '7'), false)).rejects.toThrow('network');

        const account = useOnlineProviderAccountStore.getState().accounts[providerId];
        expect(account.likedSongIds).toEqual(['7']);
    });

    it('persists the new liked list so a restart does not restore the old heart', async () => {
        vi.mocked(saveProviderAccountSnapshot).mockClear();
        registerOnlineMusicProvider(likeProvider(async () => undefined));
        seedAccount({ likedSongIds: ['7'] });

        await omni.likeSong(song(providerId, '7'), false);

        expect(saveProviderAccountSnapshot).toHaveBeenCalledWith(providerId, expect.objectContaining({
            likedSongIds: [],
        }));
    });

    it('keeps the mutation successful when persisting the snapshot fails', async () => {
        vi.mocked(saveProviderAccountSnapshot).mockRejectedValueOnce(new Error('disk full'));
        registerOnlineMusicProvider(likeProvider(async () => undefined));
        seedAccount({ likedSongIds: [] });

        await expect(omni.likeSong(song(providerId, '7'), true)).resolves.toBeUndefined();
        expect(useOnlineProviderAccountStore.getState().accounts[providerId].likedSongIds.map(String)).toEqual(['7']);
    });

    it('adds the song to likedSongIds', async () => {
        registerOnlineMusicProvider(likeProvider(async () => undefined));
        seedAccount({ likedSongIds: [] });

        const nextLiked = await omni.toggleSongLike(song(providerId, '7'));

        const account = useOnlineProviderAccountStore.getState().accounts[providerId];
        expect(nextLiked).toBe(true);
        expect(account.likedSongIds.map(String)).toEqual(['7']);
    });
});
